#ifndef __FONT_UTILITY_H
#define __FONT_UTILITY_H

int FontExists(const TCHAR *fontFace);

#endif
