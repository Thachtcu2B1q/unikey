//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by NewKey.rc
//
#define IDS_APP_TITLE                   102
#define IDR_MAINFRAME                   103
#define IDS_ABOUT                       103
#define IDM_ABOUT                       103
#define IDR_KEY_MENU                    104
#define IDD_ABOUT                       105
#define IDI_CANCEL                      117
#define IDI_OK                          118
#define IDC_HAND_CURSOR                 119
#define IDI_HELP                        120
#define IDI_RESET                       125
#define IDI_VIET                        129
#define IDD_KEY_DIALOG_VIET             129
#define IDD_KEY_DIALOG                  129
#define IDI_EN                          130
#define IDI_CONTRACT                    131
#define IDI_EXPAND                      132
#define ID_END_KEY                      1000
#define IDC_SHOW_DLG                    1001
#define IDC_CODE_TABLE                  1002
#define IDC_SW_KEY1                     1004
#define IDC_SW_KEY2                     1005
#define IDC_TELEX                       1006
#define IDC_VNI                         1007
#define IDC_ABOUT                       1008
#define IDC_FREE_MARKING                1010
#define IDC_MAIL_LINK                   1011
#define IDC_WEB_LINK                    1012
#define IDC_OPEN_HELP                   1013
#define IDC_EXIT                        1014
#define IDC_TONE_CTRL                   1018
#define IDC_RESET                       1019
#define IDC_MODERN_STYLE                1020
#define IDC_COMPACT_FRAME               1022
#define IDC_EXPAND                      1023
#define IDC_FOOTER_FRAME                1024
#define IDC_VIET_GUI                    1026
#define IDC_CONTROL_GROUP               1028
#define IDC_CHARSET_PROMPT              1029
#define IDC_KEYMODE_PROMPT              1030
#define IDC_SWITCHKEY_PROMPT            1031
#define IDC_OPTION_GROUP                1032
#define IDC_AUTHOR                      1036
#define IDC_COPYRIGHT                   1037
#define IDC_INFO                        1038
#define IDC_AUTO_START                  1040
#define ID_KEY_PANEL                    40002
#define ID_KEY_TCVN                     40008
#define ID_KEY_UNICODE                  40009
#define ID_KEY_OTHER                    40010
#define ID_TELEX_TYPING                 40011
#define ID_VNI_TYPING                   40012
#define ID_OPEN_HELP                    40015
#define ID_KEY_VIQR                     40016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         40017
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
