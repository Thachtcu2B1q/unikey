This program was released under the GNU General Public License!
Please be fair and repect the rules. I have spent hundreds of hours to write this program.

Official web site: http://unikey.hypermart.net

Build instructions:
- Open the workspace newkey\newkey.dsw
- Build NewKey project with configuration "Win32 Release Small".
Other configurations were not well tested.

I may not have time to answer questions concerning the source. So try to figure it out yourselves. And please don't blame me for poor coding:-)

Pham Kim Long 
longp@cslab.felk.cvut.cz
