

int _Xi18nGeometryCallback(XIMS ims, IMProtocol *call_data);
int _Xi18nPreeditStartCallback(XIMS ims, IMProtocol *call_data);
int _Xi18nPreeditDrawCallback(XIMS ims, IMProtocol *call_data);
int _Xi18nPreeditCaretCallback(XIMS ims, IMProtocol *call_data);
int _Xi18nPreeditDoneCallback(XIMS ims, IMProtocol *call_data);
int _Xi18nStatusStartCallback(XIMS ims, IMProtocol *call_data);
int _Xi18nStatusDrawCallback(XIMS ims, IMProtocol *call_data);
int _Xi18nStatusDoneCallback(XIMS ims, IMProtocol *call_data);
int _Xi18nStringConversionCallback(XIMS ims, IMProtocol *call_data);
