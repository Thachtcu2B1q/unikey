

void PreeditStartReplyMessageProc(XIMS ims, IMProtocol *call_data, unsigned char *p);
void PreeditCaretReplyMessageProc(XIMS ims, IMProtocol *call_data, unsigned char *p);
void StrConvReplyMessageProc(XIMS ims, IMProtocol *call_data, unsigned char *p);
void _Xi18nMessageHandler(XIMS ims, CARD16 connect_id, unsigned char *p, Bool *delete);
