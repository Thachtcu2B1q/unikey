void _Xi18nChangeIC(XIMS ims, IMProtocol *call_data, unsigned char *p, int create_flag);
void _Xi18nGetIC(XIMS ims, IMProtocol *call_data, unsigned char *p);
