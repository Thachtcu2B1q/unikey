//this file is used merely to force libtool to use g++ in linking with libUnikey

int unikey_xim_dummy()
{
  return 1;
}
