// -*- coding:unix; mode:c++; tab-width:4; c-basic-offset:4; indent-tabs-mode:nil -*-
//this file is used merely to force libtool to use g++ in linking

int unikey_gtk_dummy()
{
  return 1;
}
