The UniKey project consists of following components:
- UniKey: Vietnamese keyboard program for Windows
- UVConverter: Universal Vietnamese Encoding Converter
- vnconv (used by UniKey, UVConverter): library for Vietnamese encoding conversion.

Official web site: http://unikey.sourceforge.net

These programs were released under the GNU General Public License!
Please be fair and repect the rules. I have spent hundreds of hours to write these programs.

Build UniKey in VC++:
- Open the workspace newkey\newkey.dsw
- Build NewKey project with configuration "Win32 Release Small" or "Win 32 Unicode Release".
Other configurations were not well tested.

Build UVConverter in VC++:
- Open the workspace uvconvert\uvconvert.dsw
- Build

Build UVConverter in Linux:
- Go to directory uvconvert
- Issue command: make

I may not have time to answer questions concerning the source. So try to figure it out yourself. 
And please don't blame me for poor coding, because I know that :-)

Pham Kim Long 
longp@cslab.felk.cvut.cz
