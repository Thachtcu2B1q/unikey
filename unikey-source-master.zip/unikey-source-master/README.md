Unikey source code
==================

Clone from http://unikey.cvs.sourceforge.net/viewvc/unikey/.

